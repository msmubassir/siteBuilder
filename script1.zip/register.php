<?php
session_start();
require 'includes/config.php';

// Password requirements
define('MIN_PASSWORD_LENGTH', 8);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate inputs
    $errors = [];
    
    // Username validation
    if (empty($username)) {
        $errors[] = "Username is required";
    } elseif (strlen($username) < 4) {
        $errors[] = "Username must be at least 4 characters";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers and underscores";
    }
    
    // Password validation
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < MIN_PASSWORD_LENGTH) {
        $errors[] = "Password must be at least " . MIN_PASSWORD_LENGTH . " characters";
    } elseif ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    
    // If no errors, proceed with registration
    if (empty($errors)) {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        
        if ($stmt->fetch()) {
            $errors[] = "Username already exists!";
        } else {
            // Hash password
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            
            // Insert new user with prepared statement
            try {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, created_at) VALUES (:username, :password, NOW())");
                $stmt->execute([
                    'username' => $username,
                    'password' => $password_hash
                ]);
                
                // Redirect to login with success message
                $_SESSION['registration_success'] = true;
                header("Location: login.php");
                exit();
            } catch (PDOException $e) {
                $errors[] = "Registration failed. Please try again later.";
                error_log("Registration error: " . $e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('https://miro.medium.com/v2/resize:fit:828/format:webp/1*PHPJlMSTushbEDxJ4nAZ0Q.jpeg') no-repeat center center/cover;
            padding: 20px;
        }

        .register-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
            text-align: center;
            width: 100%;
            max-width: 400px;
            border: 2px solid rgba(255, 255, 255, 0.2);
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .register-container h2 {
            color: white;
            margin-bottom: 25px;
            font-size: 28px;
        }

        .input-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .input-group label {
            display: block;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 8px;
            font-size: 14px;
            padding-left: 5px;
        }

        .input-box {
            position: relative;
        }

        .input-box input {
            width: 100%;
            padding: 14px;
            border: none;
            outline: none;
            border-radius: 8px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.15);
            color: white;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .input-box input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .input-box input:focus {
            background: rgba(255, 255, 255, 0.25);
            transform: scale(1.02);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
        }

        .password-strength {
            height: 4px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            margin-top: 8px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .strength-meter {
            height: 100%;
            width: 0%;
            background: #ff4757;
            transition: all 0.3s ease;
        }

        .register-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6a00f4, #8e2de2);
            border: none;
            outline: none;
            color: white;
            font-size: 16px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(106, 0, 244, 0.3);
            margin-top: 10px;
        }

        .register-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(106, 0, 244, 0.4);
        }

        .register-btn:active {
            transform: translateY(0);
        }

        .login-link {
            display: block;
            margin-top: 20px;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .login-link:hover {
            color: white;
            text-decoration: underline;
        }

        .error-message {
            color: #ff6b6b;
            background: rgba(255, 0, 0, 0.1);
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-size: 14px;
            animation: shake 0.5s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }

        .password-hint {
            color: rgba(255, 255, 255, 0.6);
            font-size: 12px;
            margin-top: 5px;
            text-align: left;
            padding-left: 5px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Create Account</h2>
        
        <?php if (!empty($errors)): ?>
            <?php foreach ($errors as $error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <form method="POST" id="registerForm">
            <div class="input-group">
                <label for="username">Username</label>
                <div class="input-box">
                    <input type="text" id="username" name="username" placeholder="Enter username" 
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required>
                </div>
            </div>
            
            <div class="input-group">
                <label for="password">Password</label>
                <div class="input-box">
                    <input type="password" id="password" name="password" placeholder="At least 8 characters" required>
                    <div class="password-strength">
                        <div class="strength-meter" id="strengthMeter"></div>
                    </div>
                    <p class="password-hint">Use at least 8 characters with mix of letters and numbers</p>
                </div>
            </div>
            
            <div class="input-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="input-box">
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-type your password" required>
                </div>
            </div>
            
            <button type="submit" class="register-btn">Register Now</button>
        </form>
        
        <a href="login.php" class="login-link">Already have an account? Login here</a>
    </div>

    <script>
        // Password strength indicator
        const passwordInput = document.getElementById('password');
        const strengthMeter = document.getElementById('strengthMeter');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            // Length check
            if (password.length >= 8) strength += 1;
            if (password.length >= 12) strength += 1;
            
            // Complexity checks
            if (/[A-Z]/.test(password)) strength += 1;
            if (/[0-9]/.test(password)) strength += 1;
            if (/[^A-Za-z0-9]/.test(password)) strength += 1;
            
            // Update meter
            const width = (strength / 5) * 100;
            strengthMeter.style.width = width + '%';
            
            // Update color
            if (strength <= 1) {
                strengthMeter.style.background = '#ff4757'; // Weak (red)
            } else if (strength <= 3) {
                strengthMeter.style.background = '#ffa502'; // Medium (orange)
            } else {
                strengthMeter.style.background = '#2ed573'; // Strong (green)
            }
        });
        
        // Form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
            
            if (password.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long!');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>