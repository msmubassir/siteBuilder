<?php
session_start();
require 'includes/auth.php';
require 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["message" => "Unauthorized access"]);
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$username = $stmt->fetchColumn();

$userDir = __DIR__ . "/user/$username";
$data = json_decode(file_get_contents("php://input"), true);

$oldName = basename($data['oldName']);
$newName = basename($data['newName']);
$oldPath = "$userDir/$oldName";
$newPath = "$userDir/$newName";

if (!file_exists($oldPath)) {
    echo json_encode(["message" => "File not found"]);
    exit();
}

if (file_exists($newPath)) {
    echo json_encode(["message" => "File with new name already exists"]);
    exit();
}

rename($oldPath, $newPath);
echo json_encode(["message" => "File renamed successfully"]);
