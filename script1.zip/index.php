<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: url('https://miro.medium.com/v2/resize:fit:828/format:webp/1*PHPJlMSTushbEDxJ4nAZ0Q.jpeg') no-repeat center center/cover;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .welcome-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 500px;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        h1 {
            color: white;
            margin-bottom: 30px;
            font-size: 28px;
        }

        .auth-links {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }

        .auth-link {
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .login-link {
            background: linear-gradient(135deg, #6a00f4, #8e2de2);
            color: white;
        }

        .register-link {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .auth-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        .login-link:hover {
            background: linear-gradient(135deg, #8e2de2, #6a00f4);
        }

        .register-link:hover {
            background: rgba(255, 255, 255, 0.3);
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <h1>Welcome to Website Builder</h1>
        <div class="auth-links">
            <a href="login.php" class="auth-link login-link">Login</a>
            <a href="register.php" class="auth-link register-link">Register</a>
        </div>
    </div>
</body>
</html>