<?php
session_start();
require 'includes/config.php';
require 'includes/auth.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit();
    }

    $user_id = $_SESSION['user_id'];

    // ইউজারনেম বের করা
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $username = $stmt->fetchColumn();

    $userDir = __DIR__ . "/user/$username";
    if (!file_exists($userDir)) {
        mkdir($userDir, 0755, true);
    }

    // **ফাইল আপলোড প্রসেস**
    if (!empty($_FILES['file']['name'])) {
        $file_name = basename($_FILES['file']['name']);
        $file_tmp = $_FILES['file']['tmp_name'];
        $upload_path = "$userDir/$file_name";

        if (move_uploaded_file($file_tmp, $upload_path)) {
            echo json_encode(['status' => 'success', 'message' => 'File uploaded successfully!', 'url' => "https://$username.mubassir.site/$file_name"]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'File upload failed']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No file selected']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
