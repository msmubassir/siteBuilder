<?php
session_start();
require 'includes/auth.php';
require 'includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$filename = $data['filename'] ?? '';

if (!$filename) {
    echo json_encode(['success' => false, 'message' => 'No file specified']);
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$username = $stmt->fetchColumn();

$filePath = __DIR__ . "/user/$username/$filename";

if (file_exists($filePath)) {
    unlink($filePath);
    echo json_encode(['success' => true, 'message' => 'File deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'File not found']);
}
?>
