<?php
session_start();
require 'includes/auth.php';
require 'includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user information
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$username = $stmt->fetchColumn();

// Validate and sanitize filename
$filename = isset($_GET['file']) ? basename($_GET['file']) : '';
$filepath = __DIR__ . "/user/$username/" . $filename;

// Check if file exists and is editable
$editableExtensions = ['txt', 'html', 'htm', 'css', 'js', 'php', 'json', 'xml', 'md'];
$extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if (!file_exists($filepath) || !in_array($extension, $editableExtensions)) {
    $_SESSION['error'] = 'File cannot be edited';
    header("Location: dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['content'])) {
        // Save file content
        file_put_contents($filepath, $_POST['content']);
        $_SESSION['message'] = 'File saved successfully';
        header("Location: dashboard.php");
        exit();
    }
}

// Get file content
$content = htmlspecialchars(file_get_contents($filepath));

// Function to format file size
function formatSizeUnits($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        return $bytes . ' bytes';
    } elseif ($bytes == 1) {
        return $bytes . ' byte';
    } else {
        return '0 bytes';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit File - <?php echo htmlspecialchars($filename); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #6a00f4;
            --secondary: #ff007a;
            --dark: #1a1a2e;
            --light: #f8f9fa;
            --danger: #dc3545;
            --success: #28a745;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe') no-repeat center center/cover;
            min-height: 100vh;
            padding: 40px 10px;
            color: white;
        }
        
        .edit-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 3px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        h1 {
            margin-bottom: 20px;
            text-align: center;
        }
        
        .file-info {
            display: flex;
            justify-content: space-between;
            margin: 20px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .file-info p {
            margin: 0;
        }
        
        .editor-wrapper {
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .CodeMirror {
            height: 500px;
            font-family: 'Fira Code', 'Courier New', monospace;
            font-size: 14px;
            background: rgba(255, 255, 255, 0.1) !important;
            color: white !important;
        }
        
        .CodeMirror-gutters {
            background: rgba(0, 0, 0, 0.2) !important;
            border-right: 1px solid rgba(255, 255, 255, 0.1) !important;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .save-btn {
            background: linear-gradient(135deg, var(--success), #2E7D32);
            color: white;
        }
        
        .cancel-btn {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        
        .file-type-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            background: rgba(106, 0, 244, 0.3);
            font-size: 12px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <h1>Editing: <?php echo htmlspecialchars($filename); ?> <span class="file-type-badge"><?php echo strtoupper($extension); ?></span></h1>
        
        <div class="file-info">
            <p><strong>Location:</strong> /<?php echo htmlspecialchars($username); ?>/<?php echo htmlspecialchars($filename); ?></p>
            <p><strong>Size:</strong> <?php echo formatSizeUnits(filesize($filepath)); ?></p>
            <p><strong>Last Modified:</strong> <?php echo date("F d Y H:i:s", filemtime($filepath)); ?></p>
        </div>

        <form method="POST">
            <div class="editor-wrapper">
                <textarea id="editor" name="content"><?php echo $content; ?></textarea>
            </div>
            <div class="btn-group">
                <button type="submit" class="btn save-btn">Save Changes</button>
                <a href="dashboard.php" class="btn cancel-btn">Cancel</a>
            </div>
        </form>
    </div>

    <!-- CodeMirror for syntax highlighting -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/php/php.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/edit/matchbrackets.min.js"></script>
    
    <script>
        // Determine the mode based on file extension
        function getModeForExtension(ext) {
            const modes = {
                'js': 'javascript',
                'html': 'htmlmixed',
                'htm': 'htmlmixed',
                'css': 'css',
                'php': 'php',
                'json': {name: 'javascript', json: true},
                'xml': 'xml',
                'txt': 'null',
                'md': 'markdown'
            };
            return modes[ext] || 'null';
        }

        // Initialize CodeMirror
        const editor = CodeMirror.fromTextArea(document.getElementById('editor'), {
            lineNumbers: true,
            mode: getModeForExtension('<?php echo $extension; ?>'),
            theme: 'default',
            lineWrapping: true,
            autoCloseBrackets: true,
            matchBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            extraKeys: {
                "Ctrl-S": function(instance) {
                    document.forms[0].submit();
                }
            }
        });

        // Set editor size to fill available space
        function resizeEditor() {
            const container = document.querySelector('.edit-container');
            const headerHeight = document.querySelector('h1').offsetHeight;
            const fileInfoHeight = document.querySelector('.file-info').offsetHeight;
            const btnGroupHeight = document.querySelector('.btn-group').offsetHeight;
            const padding = 120; // Additional padding
            
            const height = container.offsetHeight - headerHeight - fileInfoHeight - btnGroupHeight - padding;
            editor.setSize("100%", Math.max(300, height));
        }

        window.addEventListener('load', resizeEditor);
        window.addEventListener('resize', resizeEditor);
    </script>
</body>
</html>