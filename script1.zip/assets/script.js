function showMessage(msg, isError = false) {
    const message = document.getElementById("message");
    message.textContent = msg;
    message.style.color = isError ? "red" : "green";
    setTimeout(() => { message.textContent = ""; }, 3000);
}

// Upload File
function uploadFile() {
    const fileInput = document.getElementById('fileInput');
    if (!fileInput.files.length) {
        showMessage('Please select a file to upload.', true);
        return;
    }

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    fetch('upload.php', { method: 'POST', body: formData })
    .then(response => response.json())
    .then(data => {
        showMessage(data.message, !data.success);
        if (data.success) loadFiles();
    })
    .catch(error => showMessage('Upload failed.', true));
}

// Load Files
function loadFiles() {
    fetch('file_list.php')
    .then(response => response.json())
    .then(data => {
        const fileList = document.getElementById('fileList');
        fileList.innerHTML = '';

        if (data.files.length === 0) {
            fileList.innerHTML = '<tr><td colspan="2">No files uploaded yet.</td></tr>';
            return;
        }

        data.files.forEach(file => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${file}</td>
                <td>
                    <button onclick="downloadFile('${file}')">Download</button>
                    <button onclick="renameFile('${file}')">Rename</button>
                    <button onclick="editFile('${file}')">Edit</button>
                    <button onclick="deleteFile('${file}')">Delete</button>
                </td>
            `;
            fileList.appendChild(row);
        });
    })
    .catch(error => showMessage('Failed to load file list.', true));
}

// Edit File
function editFile(filename) {
    // Check if the file is editable (text-based)
    const editableExtensions = ['txt', 'html', 'htm', 'css', 'js', 'php', 'json', 'xml', 'md'];
    const extension = filename.split('.').pop().toLowerCase();
    
    if (editableExtensions.includes(extension)) {
        window.location.href = `edit.php?file=${encodeURIComponent(filename)}`;
    } else {
        showMessage('This file type cannot be edited directly. Please download it instead.', true);
    }
}

// Delete File
function deleteFile(filename) {
    if (!confirm(`Are you sure you want to delete "${filename}"?`)) return;

    fetch('delete.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename })
    })
    .then(response => response.json())
    .then(data => {
        showMessage(data.message, !data.success);
        if (data.success) loadFiles();
    })
    .catch(error => showMessage('Failed to delete file.', true));
}

// Rename File
function renameFile(oldName) {
    const newName = prompt('Enter new name:', oldName);
    if (!newName || newName === oldName) return;

    fetch('rename.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ oldName, newName })
    })
    .then(response => response.json())
    .then(data => {
        showMessage(data.message, !data.success);
        if (data.success) loadFiles();
    })
    .catch(error => showMessage('Failed to rename file.', true));
}

// Download File
function downloadFile(filename) {
    window.location.href = `download.php?file=${filename}`;
}

document.addEventListener("DOMContentLoaded", loadFiles);
