<?php
session_start();
require 'includes/auth.php';
require 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$username = $stmt->fetchColumn();

$userDir = __DIR__ . "/user/$username";
if (!isset($_GET['file'])) {
    die("File not specified.");
}

$file = basename($_GET['file']);
$filePath = "$userDir/$file";

if (!file_exists($filePath)) {
    die("File not found.");
}

header("Content-Description: File Transfer");
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"" . basename($file) . "\"");
header("Expires: 0");
header("Cache-Control: must-revalidate");
header("Pragma: public");
header("Content-Length: " . filesize($filePath));
readfile($filePath);
exit();
