<?php
session_start();
require 'includes/auth.php';
require 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);
$username = $stmt->fetchColumn();

$websiteURL = "https://$username.mubassir.site";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe') no-repeat center center/cover;
            padding: 40px 20px;
            color: white;
        }

        .dashboard-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
            width: 90%;
            max-width: 800px;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        h1, h2 {
            color: white;
            margin-bottom: 20px;
            text-align: center;
        }

        p {
            margin-bottom: 20px;
            text-align: center;
        }

        a {
            color: #6a00f4;
            text-decoration: none;
            transition: 0.3s;
        }

        a:hover {
            color: #ff007a;
            text-decoration: underline;
        }

        .upload-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 30px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
        }

        #fileInput {
            width: 100%;
            max-width: 400px;
            padding: 12px;
            margin-bottom: 15px;
            border: none;
            outline: none;
            border-radius: 8px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            transition: 0.3s ease-in-out;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        button {
            width: 100%;
            max-width: 200px;
            padding: 12px;
            background: linear-gradient(135deg, #ff007a, #6a00f4);
            border: none;
            outline: none;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
            box-shadow: 0 0 10px rgba(255, 0, 122, 0.6);
            margin: 2px;
        }

        button:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(255, 0, 122, 0.8);
        }

        #message {
            margin-top: 15px;
            color: rgba(255, 255, 255, 0.9);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        th {
            background: rgba(255, 255, 255, 0.2);
            font-weight: 600;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.15);
        }

        .logout-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: rgba(255, 0, 122, 0.3);
            border-radius: 8px;
            transition: 0.3s;
            color: white;
        }

        .logout-link:hover {
            background: rgba(255, 0, 122, 0.5);
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h1>Welcome to Your Dashboard</h1>
        
        <!-- Display the Website URL -->
        <p>Your website is: <a href="<?= $websiteURL ?>" target="_blank"><?= $websiteURL ?></a></p>

        <!-- Upload Form -->
        <div class="upload-section">
            <input type="file" id="fileInput">
            <button onclick="uploadFile()">Upload</button>
            <p id="message"></p>
        </div>

        <!-- File List Table -->
        <h2>Your Uploaded Files</h2>
        <table>
            <thead>
                <tr>
                    <th>Filename</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="fileList">
                <!-- Files will be loaded here -->
            </tbody>
        </table>

        <p><a href="logout.php" class="logout-link">Logout</a></p>
    </div>
    <script src="assets/script.js?v=<?php echo time(); ?>" defer></script>
</body>
</html>