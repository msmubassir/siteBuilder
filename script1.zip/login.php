<?php
session_start();
require 'includes/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: url('https://miro.medium.com/v2/resize:fit:828/format:webp/1*PHPJlMSTushbEDxJ4nAZ0Q.jpeg') no-repeat center center/cover;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
            text-align: center;
            width: 350px;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }

        .login-container h2 {
            color: white;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .input-box {
            position: relative;
            margin-bottom: 20px;
        }

        .input-box input {
            width: 100%;
            padding: 12px;
            border: none;
            outline: none;
            border-radius: 8px;
            font-size: 16px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            transition: 0.3s ease-in-out;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .input-box input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .input-box input:focus {
            background: rgba(255, 255, 255, 0.4);
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #ff007a, #6a00f4);
            border: none;
            outline: none;
            color: white;
            font-size: 18px;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s ease-in-out;
            box-shadow: 0 0 10px rgba(255, 0, 122, 0.6);
        }

        .login-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(255, 0, 122, 0.8);
        }

        .forgot {
            margin-top: 15px;
            display: block;
            color: rgba(255, 255, 255, 0.7);
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .forgot:hover {
            color: white;
        }
    </style>
</head>

<body>

    <div class="login-container">
        <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <h2>Login</h2>
        <form method="POST">
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button class="login-btn" type="submit">Login</button>
        </form>
        <a href="register.php" class="forgot">Register here</a>
    </div>

</body>

</html>